import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _formKey = GlobalKey<FormState>();
  final _cepEdit = TextEditingController();
  bool loading = false;

  dynamic address;

  @override
  void dispose() {
    _cepEdit.dispose();
    super.dispose();
  }

  Future<dynamic> getReq(String cep) async {
    var dio = Dio();
    final response = await dio.get('https://viacep.com.br/ws/$cep/json/');
    return response.data;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Center(
          child: Text(
            'Consulta CEP',
          ),
        ),
      ),
      body: Column(
        children: [
          Form(
            key: _formKey,
            child: TextFormField(
              controller: _cepEdit,
            ),
          ),
          ElevatedButton(
            onPressed: () async {
              setState(() {
                loading = true;
              });
              final reqs = await getReq(_cepEdit.text);
              setState(() {
                address = reqs;
                loading = false;
              });
            },
            child: const Text(
              'Consultar',
            ),
          ),
          SizedBox(
            height: 20,
          ),
          (loading)
              ? const CircularProgressIndicator()
              : Column(
                  children: [
                    Text(
                        'Endereço: ${address != null ? address["logradouro"] : ""}',
                        style: const TextStyle(fontSize: 20)),
                    Text(
                        'Número: ${address != null ? address["complemento"] : ""}',
                        style: const TextStyle(fontSize: 20)),
                    Text('Bairro: ${address != null ? address["bairro"] : ""}',
                        style: const TextStyle(fontSize: 20)),
                    Text(
                        'Cidade: ${address != null ? address["localidade"] : ""}',
                        style: const TextStyle(fontSize: 20))
                  ],
                )
        ],
      ),
    );
  }
}
